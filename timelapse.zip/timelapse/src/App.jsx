import { useState, useRef } from "react";

export default function App() {
  const [images, setImages] = useState([]);
  const [fps, setFps] = useState(24);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [videoUrl, setVideoUrl] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [resolution, setResolution] = useState(1.0);
  const canvasRef = useRef(null);

  const handleFiles = (files) => {
    const imageFiles = Array.from(files)
      .filter((f) => f.type.startsWith("image/"))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    setImages(imageFiles);
    setVideoUrl(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const loadImage = (file) =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.src = URL.createObjectURL(file);
    });

  const createTimelapse = async () => {
    if (images.length === 0) return;
    setIsProcessing(true);
    setProgress(0);
    setVideoUrl(null);

    const canvas = canvasRef.current;
    const firstImg = await loadImage(images[0]);
    canvas.width = Math.round(firstImg.width * resolution);
    canvas.height = Math.round(firstImg.height * resolution);
    const ctx = canvas.getContext("2d");

    const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
      ? "video/webm;codecs=vp9"
      : "video/webm";
    const stream = canvas.captureStream(fps);
    const chunks = [];
    const recorder = new MediaRecorder(stream, { mimeType });
    recorder.ondataavailable = (e) => e.data.size > 0 && chunks.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: "video/webm" });
      setVideoUrl(URL.createObjectURL(blob));
      setIsProcessing(false);
    };

    recorder.start();
    const frameTime = 1000 / fps;

    for (let i = 0; i < images.length; i++) {
      const img = await loadImage(images[i]);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      setProgress(Math.round(((i + 1) / images.length) * 100));
      await new Promise((r) => setTimeout(r, frameTime));
    }

    recorder.stop();
  };

  const duration = images.length > 0 ? (images.length / fps).toFixed(1) : null;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0d0d0d",
      color: "#f0f0f0",
      fontFamily: "'Inter', system-ui, sans-serif",
      padding: "32px 24px",
    }}>
      <div style={{ maxWidth: 560, margin: "0 auto" }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 11, letterSpacing: "0.15em", color: "#666", textTransform: "uppercase", marginBottom: 6 }}>
            Project Lemonwater
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, margin: 0, lineHeight: 1.2 }}>
            Timelapse Maker
          </h1>
          <p style={{ color: "#888", marginTop: 8, fontSize: 14 }}>
            Drop your print photos in, get a video out.
          </p>
        </div>

        <div
          onDrop={handleDrop}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onClick={() => document.getElementById("fileInput").click()}
          style={{
            border: `2px dashed ${dragging ? "#00e5ff" : images.length > 0 ? "#333" : "#444"}`,
            borderRadius: 12,
            padding: "36px 24px",
            textAlign: "center",
            cursor: "pointer",
            background: dragging ? "rgba(0,229,255,0.05)" : "#141414",
            transition: "all 0.15s ease",
            marginBottom: 20,
          }}
        >
          <div style={{ fontSize: 40, marginBottom: 10 }}>
            {images.length > 0 ? "🎞️" : "📂"}
          </div>
          {images.length > 0 ? (
            <>
              <div style={{ fontWeight: 600, fontSize: 16 }}>{images.length} photos loaded</div>
              <div style={{ color: "#888", fontSize: 13, marginTop: 4 }}>
                Sorted by filename · {duration}s at {fps}fps · Click to change
              </div>
            </>
          ) : (
            <>
              <div style={{ fontWeight: 500 }}>Drop photos here or click to select</div>
              <div style={{ color: "#666", fontSize: 13, marginTop: 4 }}>Supports JPG, PNG, HEIC</div>
            </>
          )}
          <input
            id="fileInput"
            type="file"
            multiple
            accept="image/*"
            style={{ display: "none" }}
            onChange={(e) => handleFiles(e.target.files)}
          />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
          <div style={{ background: "#141414", borderRadius: 10, padding: "14px 16px" }}>
            <label style={{ fontSize: 11, color: "#888", letterSpacing: "0.1em", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
              Frame Rate
            </label>
            <select
              value={fps}
              onChange={(e) => setFps(Number(e.target.value))}
              style={{ background: "#1e1e1e", color: "#f0f0f0", border: "1px solid #333", borderRadius: 6, padding: "6px 10px", fontSize: 14, width: "100%" }}
            >
              <option value={10}>10 fps — slow</option>
              <option value={15}>15 fps</option>
              <option value={24}>24 fps — cinematic</option>
              <option value={30}>30 fps — smooth</option>
            </select>
          </div>
          <div style={{ background: "#141414", borderRadius: 10, padding: "14px 16px" }}>
            <label style={{ fontSize: 11, color: "#888", letterSpacing: "0.1em", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
              Resolution
            </label>
            <select
              value={resolution}
              onChange={(e) => setResolution(Number(e.target.value))}
              style={{ background: "#1e1e1e", color: "#f0f0f0", border: "1px solid #333", borderRadius: 6, padding: "6px 10px", fontSize: 14, width: "100%" }}
            >
              <option value={0.5}>50% — small file</option>
              <option value={0.75}>75%</option>
              <option value={1.0}>100% — full res</option>
            </select>
          </div>
        </div>

        <button
          onClick={createTimelapse}
          disabled={images.length === 0 || isProcessing}
          style={{
            width: "100%",
            padding: "14px",
            borderRadius: 10,
            border: "none",
            background: images.length === 0 || isProcessing ? "#1e1e1e" : "#00e5ff",
            color: images.length === 0 || isProcessing ? "#555" : "#000",
            fontWeight: 700,
            fontSize: 15,
            cursor: images.length === 0 || isProcessing ? "not-allowed" : "pointer",
            transition: "all 0.15s ease",
          }}
        >
          {isProcessing ? `Building timelapse… ${progress}%` : "Create Timelapse"}
        </button>

        {isProcessing && (
          <div style={{ marginTop: 12, background: "#1e1e1e", borderRadius: 999, height: 4, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${progress}%`, background: "#00e5ff", borderRadius: 999, transition: "width 0.2s ease" }} />
          </div>
        )}

        {videoUrl && (
          <div style={{ marginTop: 24 }}>
            <video src={videoUrl} controls autoPlay loop style={{ width: "100%", borderRadius: 10, background: "#000" }} />
            <a
              href={videoUrl}
              download="timelapse.webm"
              style={{
                display: "block", marginTop: 10, padding: "13px", borderRadius: 10,
                background: "#141414", border: "1px solid #333", color: "#00e5ff",
                textDecoration: "none", textAlign: "center", fontWeight: 600, fontSize: 14,
              }}
            >
              Download timelapse.webm
            </a>
            <p style={{ color: "#555", fontSize: 12, textAlign: "center", marginTop: 8 }}>
              .webm works on PC · convert to MP4 for iPhone/iMovie
            </p>
          </div>
        )}

        <canvas ref={canvasRef} style={{ display: "none" }} />
      </div>
    </div>
  );
}
